import { Component } from "react";
import PopUp from "./component/popup.component";

class App extends Component{
    state = {
        title : "welcome",
        showpopup : false,
        changeTitle : "Changed to PopUp"
    }
    togglePopup = ()=>{
        this.setState({
            showpopup : !this.state.showpopup
        })
    }
    changeTitle = ()=>{
        this.setState({
            changeTitle : this.state.changeTitle

        })
    }
    render(){
        return <div>
            <h1>{this.state.title}</h1>
            { this.state.showpopup ?
            <PopUp>
                <div>
                    <h2>PopUp Window</h2>
                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Magni nam accusamus totam rem assumenda. Totam doloremque explicabo repudiandae tempore incidunt possimus ducimus sunt, ea, cumque accusamus maiores dolores aut quasi!
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt totam eveniet ipsam labore velit harum expedita, obcaecati qui at consequuntur, quod accusamus esse tempora voluptatem quidem, nostrum sapiente blanditiis a.
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi voluptas accusantium nam odit quaerat vitae tenetur minima labore nisi fugiat aspernatur, sed quae eos optio dolores tempore? Molestias, autem velit!
                    </p>
                    <button onClick={this.togglePopup}>Hide the PopUp</button>
                    <button onClick={this.changeTitle}>Change the title</button>
                </div>
            </PopUp> : <button onClick={this.togglePopup}>Show the PopUp</button>
    }
            
        </div>

        
    }
}
export default App