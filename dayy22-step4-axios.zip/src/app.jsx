import { Component } from "react";
import GridComp from "./component/grid.component";



class App extends Component{
    state = {
        apptitle : "External Data",
        
    }
   
    
    render(){
        return <div className="container">
            <h1>
                User's List
            </h1>
                <GridComp/>
               </div>
    }
}
export default App