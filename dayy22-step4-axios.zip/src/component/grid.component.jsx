import { Component } from "react";
import axios from "axios";

class GridComponent extends Component{
    state = {
        users : []
        
    }
    localData = ()=>{
        axios.get("https://reqres.in/api/users?page=2").then(res =>{
            this.setState({
                users : res.data.data
            })
        })
    }
    componentDidMount(){
        this.localData();
    }
    render(){
        return <table class="table">
        <thead>
          <tr>
            <th scope="col">Sl No.</th>
            <th scope="col">Photos</th>
            <th scope="col">First_Name</th>
            <th scope="col">Last_Name</th>
            
          </tr>
        </thead>
        <tbody>
          {
            this.state.users.map((val,idx)=>{
                return <tr key={val.id}>
                        <td>{idx+1}</td>
                        {/* <td>{val.id+1}</td> this must be used*/} 
                        <td><img width={50} src={val.avatar} alt={val.first_name} /></td>
                        <td>{val.first_name}</td>
                        <td>{val.last_name}</td>
                        </tr>
            })
          }
          
        </tbody>
      </table>
    }
}
export default GridComponent