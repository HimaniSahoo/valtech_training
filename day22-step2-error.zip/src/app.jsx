import { Component } from "react";
import ErrorBoundary from "./component/error.component";
import HeroComp from "./component/hero";


class App extends Component{
    state = {
        title : "Welcome",
        
    }
    
    render(){
            return <div>
                <h1>{this.state.title}</h1>
                <ErrorBoundary><HeroComp power={Math.round(Math.random() * 10)}/></ErrorBoundary>
                <ErrorBoundary><HeroComp power={Math.round(Math.random() * 10)}/></ErrorBoundary>
                <ErrorBoundary><HeroComp power={Math.round(Math.random() * 10)}/></ErrorBoundary>
                <ErrorBoundary><HeroComp power={Math.round(Math.random() * 10)}/></ErrorBoundary>
                <ErrorBoundary><HeroComp power={Math.round(Math.random() * 10)}/></ErrorBoundary>
            
                
            </div>
            
        
    }
}
export default App