
import Items from "./product.comp"

let App = ()=>{
    return <div className="container">
        <h1 style={{textAlign:"center", backgroundColor:"darkviolet", margin: "10px",display:"block"}}>Avengers Store</h1>
        <Items/>
    </div>
}
export default App