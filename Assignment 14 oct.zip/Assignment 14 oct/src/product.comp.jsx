import { useEffect } from "react"
import axios from "axios";
import { useState } from "react";
 
var total = 0;
var grandtotal = 0
let Items = ()=>{
    let [hero, setHeroes] = useState([]);
    let [quantity,getQuantity] = useState({quantity:0});
    let [nitem,setItem]=useState({_id:'',hero:'',name:'',price:'',instock:true})
   
 
    let refresh = ()=>{
        axios.get("http://localhost:2020/data").then(res => {
            setHeroes(res.data);
        })
    }
 
    useEffect(function(){
       refresh();
    },[]);

    let clickHandler=(evt)=>{
        getQuantity({...quantity, quantity : Number(evt.target.value)})
    }

    let addItem=(pid)=>{
        axios.get("http://localhost:2020/edit/"+pid).then(res => {
            setItem(res.data);
            total= quantity.quantity*res.data.price
            grandtotal+= quantity.quantity*res.data.price
        })
    }

    
    
    return<div style={{display:"flex"}}>
        <div  className="container" style={{display : "flex", flexWrap : "wrap", gap:"2rem"}}>
        
        {
            hero.map((value,idx)=>{
                return <div className="herodiv" style={{color : "white", backgroundColor : "black" ,padding:"10px", margin:"10px", width:"300px", border: "5px solid black", display:"block"}}>
                            <h2>Title :{value.hero}</h2>
                            <h2>Price :{value.price}</h2>
                            Quantity<br/>    
                            <div style={{display : "flex", gap : "2rem" }}>
                                <input  type="number" min="0" onBlur={(evt)=> clickHandler(evt)} style={{width : "50px", backgroundColor:"darkviolet"}}/>
                                <input type="button" value="Add to Cart"  onClick={()=>addItem(value._id)} style={{ backgroundColor:"darkviolet"}}/>

                            </div>
                           
                 </div>
                   
                    
            })
        }

    </div>
    <div className="aside" style={{backgroundColor:"black", justifyContent:"center", width:"300px", height:"790px",color:"white"}}>
        <center><h2>Bill</h2></center>
        <div  style={{ margin:"10px", padding:"5px"}}>
        <p> Item Name: {nitem.hero}</p>
        <p>Price: {nitem.price}</p>
        <p>Quantity: {quantity.quantity}</p>
         <p>Total: {total}</p>      
         <p> Grand Total: {grandtotal}</p>      
        </div>
        <br/>
        
        </div>    
    </div>
            
}
 
export default Items
 
