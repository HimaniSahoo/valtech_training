import { Component } from "react";
import PropTypes from "prop-types";

class ChildComp extends Component{

    static propTypes = {
        title : PropTypes.string.isRequired,
        power : PropTypes.number.isRequired,
        version : PropTypes.number.isRequired
    }
    // static defaultProps  = {
    //     title : 'default prop',
    //     power : 0,
    //     version : 0
    // }
    render(){
        return<div>
                <h2>Child Component</h2>
                <h4>Title: {this.props.title}</h4>
                <h4>Power: {this.props.power}</h4>
                <h4>Version: {this.props.version}</h4>
            </div>
    }

}

ChildComp.defaultProps  = {
    title : 'default prop',
    power : 0,
    version : 0
}
export default ChildComp;