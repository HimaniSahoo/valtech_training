import { Component } from "react";
//import PropTypes from "prop-types";

class ChildComp extends Component{

    state = {
        title : "Default Title"
    }

    increasePower = ()=>{
        this.setState({
            power : this.state.power + 1
        });
    }

    setPower = (evt)=>{
        this.setState({
            power : Number(evt.target.value)
        })
        
    }
    changePower = ()=>{

    }
    // static propTypes = {
    //     title : PropTypes.string.isRequired,
    //     power : PropTypes.number.isRequired,
    //     version : PropTypes.number.isRequired
    // }
    // static defaultProps  = {
    //     title : 'default prop',
    //     power : 0,
    //     version : 0
    // }
    render(){
        return<div>
                <h2>Child Component</h2>
                <h4>Title: {this.state.title}</h4>
                <h4>Power: {this.state.power}</h4>
                 {/*<h4>Version: {this.props.version}</h4> */}
                <button onClick={()=>{
                    this.setState({
                        title : "Changed"
                    });
                }}>Changed Title</button>
                
               {/* <button onClick={ this.increasePower.bind(this)}>Increase Power</button>
               <button onClick={ ()=> this.increasePower}>Increase Power</button> */}
               <button onClick={this.increasePower}>Increase Power</button>
      
               <button onClick={event=>(this.setPower.event)}>Set Power</button>
               
            </div>
    }

}

// ChildComp.defaultProps  = {
//     title : 'default prop',
//     power : 0,
//     version : 0
// }
export default ChildComp;