import { Component } from "react";
//import PropTypes from "prop-types";

class ChildComp extends Component{

    state = {
        power : 0
    }

    increasePower = ()=>{
        this.setState(function(currentState, currentProp){
            return{
                power : currentState.power + 1
            }
        },function(){
            console.log(this.state.power);           
        });
    }

   
    // }
    render(){
        return<div>
                <h2>Child Component | power is {this.state.power}</h2>
               <button onClick={this.increasePower}>Increase Power</button>  
            </div>
    }

}
export default ChildComp;