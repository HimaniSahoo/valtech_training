//import { Component } from "react";
import { createRoot } from "react-dom/client";
import AppComp from "./components/app";

 
 
createRoot(document.getElementById("root"))
.render( <AppComp/> );