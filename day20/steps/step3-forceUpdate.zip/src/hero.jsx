import { Component } from "react";

class Hero extends Component{
    //rating = 25;
    render(){
        
         return <div>
                        <h2>{this.props.title.toLowercase().length}</h2>
                        {/* <h3>{ this.props.version+20 }</h3> */}
                        {/* <h3>Rating {this.rating}</h3> */}
                        {/* <ol>{
                            this.props.list.map((val,idx)=>{
                                return <li key={idx}> {val} </li>
                            })
                        } </ol>
                        <button onClick={()=>{
                            this.rating = this.rating+1;
                            this.forceUpdate()
                        
                        }}>Change Version</button> */}
                </div>
    }
}

export default Hero