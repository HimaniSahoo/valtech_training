import { Component } from "react";
import  Hero  from "./hero";


class App extends Component{
    //avengers = ['thor', 'superman'];
    //indichero = ['shaktiman', 'rogo'];

    render(){
        return  <div>
                    <Hero  title="PQR" ></Hero>
                    <Hero  title="MNO" ></Hero>
                    
                </div>
    } 
} 
export default App