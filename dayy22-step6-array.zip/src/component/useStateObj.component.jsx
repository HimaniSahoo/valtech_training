import { useState } from "react";

let UseStateObjComp =()=>{
    console.log(useState());
    let [power, setPower] = useState(0) //the default value that u assign to power
    let increasePower = function(){
        setPower(power+1)
    }
    return <div>
        <h1>User State Object Hook Component</h1>
        <h2>Power : { power }</h2>
        <button onClick={ increasePower }>Increase Power</button>
    </div>
}
export default UseStateObjComp