import { Component } from "react";
import UseStateAssignmentComp from "./component/useStateAssignment.component";
import UseStateComp from "./component/useStateAssignment.component";
import UseStateObjComp from "./component/useStateObj.component";




class App extends Component{
    state = {
        apptitle : "Hooks",
        
    }
   
    
    render(){
        return <div className="container">
            <h1>
                {this.state.apptitle}
            </h1>
                <UseStateComp/>
                <UseStateObjComp/>
                <UseStateAssignmentComp/>
               </div>
    }
}
export default App