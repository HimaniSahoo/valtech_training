const fs = require("fs");
const process = require("process");

let data = `\n  Hero : ${process.argv[2]}\n First Name : ${process.argv[3]}\n Last Name : ${process.argv[4]}\n  Power : ${process.argv[5]}\n `

fs.appendFile("../avengers/data.txt",data, (error) => {
    if (error) {
      console.log(error);
    }else {
        console.log(fs.readFileSync("../avengers/data.txt", "utf8"));
    }
})