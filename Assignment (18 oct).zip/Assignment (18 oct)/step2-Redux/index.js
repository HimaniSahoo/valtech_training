let redux = require("redux");
let fs = require("fs")
let createStore = redux.legacy_createStore

const AVENGERS = "AVENGERS"

let addavengers = ()=>{
    return{
        type : AVENGERS
    }
}

let initialState ={
    noOfAvengers : ""
}

let reducer = (state =initialState, action)=>{
    let avg_data = new Array()
    let data = fs.readFileSync('../avengers/data.txt' , 'ascii')
    avg_data.push(data)
    switch(action.type){
        case AVENGERS : return {noOfAvengers : avg_data}
        default : return state
    }
}

let store = createStore(reducer)

let unsubscribe = store.subscribe(()=> console.log("Subscribed", store.getState()));

 store.dispatch(addavengers());