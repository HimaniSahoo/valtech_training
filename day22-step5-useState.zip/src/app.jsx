import { Component } from "react";
import UseStateComp from "./component/useState.component";
import UseStateObjComp from "./component/useStateObj.component";




class App extends Component{
    state = {
        apptitle : "Hooks",
        
    }
   
    
    render(){
        return <div className="container">
            <h1>
                {this.state.apptitle}
            </h1>
                <UseStateComp/>
                <UseStateObjComp/>
               </div>
    }
}
export default App