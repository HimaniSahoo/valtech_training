import { useState } from "react";

let UseStateComp =()=>{
    //console.log(useState());
    let [hero, setHero] = useState({firstname : "" ,lastname : ""}) //the default value that u assign to power
    // let addHeroInfo = function(){
    //     setHero({
    //     firstname : "Tony",
    //     lastname : "Stark"
    // })
    // }
    let addHeroFirstName = function(evt){
        setHero({

        
            firstname : evt.target.value
        })
    }
    let addHeroLastName = function(evt){
        setHero({
            lastname : evt.target.value
        })
    }
    return <div>
        <h1>User State Hook Component</h1>
        <h2> First Name : { hero.firstname }</h2>
        <h2>Last Name : { hero.lastname }</h2>
        <label htmlFor="ftname"> First Name
            <input title="firstname" onChange={evt=>{addHeroFirstName(evt)} } type="text"/>    
        </label>
        <label htmlFor="lname" >Last Name
            <input title="lastname" onChange={evt=>{addHeroLastName(evt)} } type="text"/>    
        </label>
    </div>
}
export default UseStateComp